package com.example.clinicaodontologica;

import static com.example.clinicaodontologica.R.id.lvPrecios;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class Lista_precios extends AppCompatActivity {
    ListView  lvPrecios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_precios);
        lvPrecios = (ListView) findViewById(R.id.lvPrecios);
        ArrayAdapter<String> adapterPrecios=new ArrayAdapter<String>(this, R.layout.activity_lista_precios, R.id.tvPrecios);
        lvPrecios.setAdapter(adapterPrecios);

    }



}