package com.example.clinicaodontologica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class Listado_productos extends AppCompatActivity {
   // private TextView tv1; //muestra el nombre del usuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_productos);

    }
    public void Regresar(View view){
        Intent atraz = new Intent(this, MainActivity.class);
        startActivity(atraz);
    }

}