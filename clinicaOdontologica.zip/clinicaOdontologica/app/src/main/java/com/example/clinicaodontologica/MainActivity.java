package com.example.clinicaodontologica;

import static com.example.clinicaodontologica.R.id.lvPrecios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    //private EditText edtNombre;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Siguiente(View view){
        Intent avanzar = new Intent(this, Listado_productos.class);
        //avanzar.putExtra("dato",edtNombre.getText().toString());
        startActivity(avanzar);

    }


}